<?php

return [
    'name' => 'Name',
    'name_validation' => "Name is required",
    'key' => "Key",
    'value' => "Value",
    
    'setting_created' => "Setting was successfully created",
    'setting_updated' => "Setting was successfully updated",
    'setting_deleted' => "Setting was successfully deleted",
];