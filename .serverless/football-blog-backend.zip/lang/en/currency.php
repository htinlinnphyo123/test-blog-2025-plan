<?php

return[
    "rate"=>"Rate",
    "country_id"=>"Country",
    "date"=>"Date",
    "time"=>"Time",

    'rate_validation' => "Rate is required",

    'currency_created' => "Currency was successfully created",
    'currency_updated' => "Currency was successfully updated",
    'currency_deleted' => "Currency was successfully deleted",
];