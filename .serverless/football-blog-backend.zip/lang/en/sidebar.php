<?php

return [
    'main_heading' => "Buddhist News",
    'main_heading_short' => "B.N...",
    'dashboard' => "Dashboard",
    'user' => "User",
    'country' => "Country",
    'audit' => "Audit",
    'setting' => "Setting",
    'role' => "Role",
    'address' => "Address",
    'category' => "Category",
    'subcategory' => "Sub-Category",
    'notification' => "Pop Up Dialog",
    'title_country' => "Country",
    'article' => 'Articles',
    'currency' => 'Currency',
    'page' => 'Pages',
    'catagory_menu' => 'Category',
    'sponsorAd' => 'Sponsor Ads'
];
