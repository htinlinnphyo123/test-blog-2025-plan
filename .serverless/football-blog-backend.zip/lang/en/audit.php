<?php
return [
    'id' => "ID",
    'model' => "Model",
    'event' => "Event",
    'old_data' => "Old Data",
    'new_data' => "New Data",
    'created_by' => "Created By",
    'created_at' => "Created At",
];
