<?php
return [
    'id' => "အမှတ်သညာ",
    'model' => "မော်ဒယ်",
    'event' => "ဖြစ်ရပ်",
    'old_data' => "ဒေတာဟောင်း",
    'new_data' => "ဒေတာအသစ်",
    'created_by' => "ဖန်တီးသူ",
    'created_at' => "ဖန်တီးချိန်",
];
