<?php
return [
    'main_heading' => "ဗုဒ္ဓဘာသာသတင်း",
    'main_heading_short' => "ဗု.ဒ္ဓ...",
    'dashboard' => "ဒက်ရှ်ဘုတ်",
    'user' => "အသုံးပြုသူများ",
    'country' => "နိုင်ငံများ",
    'user_country' => "အသုံးပြသူနှင့်နိုင်ငံများ",
    'setting' => "ဆက်တင်",
    'audit' => "စာရင်းစစ်",
    'address' => "နေရပ်လိပ်စာ",
    'category' => "ခေါင်းစဉ်ကြီး",
    'subcategory' => "ခေါင်းစဉ်ငယ်",
    'notification' => "အကြောင်းကြားချက်",
    'title_country' => "နိုင်ငံဆက်တင်",
    'article' => 'သတင်း',
    'currency' => 'ငွေကြေးလဲလှယ်နှုန်း',
    'page' => 'စာမျက်နှာများ',
];
