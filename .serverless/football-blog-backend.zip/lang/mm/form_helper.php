<?php

return [
    'name' => 'Name should be between 5 to 255 chars.',
    'description' => 'When you insert photo, Please choose file smaller than 2MB.',
    'measure' => 'Square meter(သို့မဟုတ်)Square feetဖြင့်သာ',
    'password' => 'စကားဝှက် အသစ်ပြုလုပ်လိုမှသာလျှင် ဖြည့်ပါ',
    'article_site_url' => 'Please fill article link from Wordpress site.'
];