<?php

return [
    'login_title'=>"ចំណងជើងចូល",
    'title' => 'ចំណងជើង',
    'user_name'=>'ឈ្មោះអ្នកប្រើប្រាស់',
    'password'=>'ពាក្យសម្ងាត់',
    'wrong_credential'=>'លិខិតសម្គាល់ខុស',
    'login_btn'=>"ចូល",
    'profile_btn' => "ប្រវត្តិរូប",
    'save'=>"រក្សាទុក",
    'update'=>"ធ្វើបច្ចុប្បន្នភាព",
    'create'=>"បង្កើត",  
    'cancel'=>"បោះបង់",
    'search_item'=>"ស្វែងរកធាតុ",
    'search'=>"ស្វែងរក",
    'edit'=>"កែសម្រួល",
    'show' => 'បង្ហាញ',
    'delete'=>"លុប",
    'next'=>"បន្ទាប់",
    'previous'=>"មុន"
];