<?php

return [
    'name' => "Name KHR ",
    'role_created' => 'Role Created Successfully KHR',
    'role_updated' => 'Role Updated Successfully KHR',
    'role_deleted' => 'Role Deleted Successfully KHR'
];