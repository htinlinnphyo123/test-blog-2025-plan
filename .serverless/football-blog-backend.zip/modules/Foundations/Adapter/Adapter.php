<?php
// Nothing last forever we can change the future
?>
