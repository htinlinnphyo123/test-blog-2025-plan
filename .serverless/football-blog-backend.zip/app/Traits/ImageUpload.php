<?php

namespace App\Traits;

trait ImageUpload
{
    //
}
