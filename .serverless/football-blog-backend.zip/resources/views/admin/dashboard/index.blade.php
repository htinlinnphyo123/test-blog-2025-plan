<x-master-layout name="Dashboard" headerName="{{ __('sidebar.dashboard') }}" class="">

    <main class="h-full overflow-y-auto">
        Hello World
    </main>
</x-master-layout>
