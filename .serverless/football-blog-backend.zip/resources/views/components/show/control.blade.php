<div class="mb-4 py-2 md:px-2">
    {{ $slot }}
</div>