@props(['column','style'=>null])
<th scope="col" class="px-6 py-3 {{$style}}">
    {{ __($column) }}
</th>
