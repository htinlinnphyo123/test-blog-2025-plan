<tr class="bg-white dark:text-white hover:bg-gray-50 dark:hover:bg-gray-600 border-b dark:bg-gray-800 dark:border-gray-700 items-center ">
    {{ $slot }}
</tr>