<div class="relative overflow-x-auto shadow-md sm:rounded-lg mt-4 lg:mt-10 mb-2 lg:mb-4 mx-1">
    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
        {{ $slot }}
    </table>
</div>