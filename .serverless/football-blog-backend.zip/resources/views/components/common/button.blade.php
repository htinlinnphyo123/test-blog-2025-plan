<button
    class="px-2 mx-2 text-bold text-1xl py-1 mt-4 rounded-md
    active:border-2 focus:border-2 bg-theme text-white duration-300 transform"
    type="{{ $attributes['type'] }}" id="{{ $attributes['id'] }}">
    {{ $attributes['title'] }}
</button>