<a href="{{ url()->previous() }}" class="{{ config('config.sampleForm.buttonCreate') }} mt-2 bg-theme">
    <button type="button" class="">
        <i class="fa-solid fa-backward me-4"></i>Back
    </button>
</a>
