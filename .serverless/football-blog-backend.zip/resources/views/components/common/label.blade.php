<label class="pb-2 pt-2 text-sm px-1 text-gray-900 dark:text-white font-mono" for="{{ $attributes['for'] }}">
    {{ $attributes['title'] }}
</label>
