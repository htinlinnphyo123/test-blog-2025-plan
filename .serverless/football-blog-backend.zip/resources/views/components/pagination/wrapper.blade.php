<div class="lg:flex justify-center items-center">
    {{ $slot }}
</div>