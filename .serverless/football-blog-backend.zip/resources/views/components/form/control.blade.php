<div class="mb-4 py-2">
    {{ $slot }}
</div>