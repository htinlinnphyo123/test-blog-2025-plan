<div class="grid gap-2 md:gap-4 md:grid-cols-2">
    {{ $slot }}
</div>