<div class="mx-2 md:mx-10 mt-10 mb-10 lg:mb-20">
    {{ $slot }}
</div>