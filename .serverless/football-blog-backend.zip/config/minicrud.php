<?php

return [
    'namespace' => 'BasicDashboard',
    'modules' => 'modules',
];
