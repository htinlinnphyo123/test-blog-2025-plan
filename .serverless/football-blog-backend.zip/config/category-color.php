<?php

return [
    'ពុទ្ធសាសនា_color' => env('ពុទ្ធសាសនា_color','#f54336'), //Buddhism
    'ពុទ្ធសាសនាសង្គម_color' => env('ពុទ្ធសាសនាសង្គម_color','#e91e63'), // Social
    'ពុទ្ធសាសនាសេដ្ឋកិច្ច_color' => env('ពុទ្ធសាសនាសេដ្ឋកិច្ច_color','#2a7bba'), //Economic
    'ទេសចរណ៍ពុទ្ធសាសនា_color' => env('ទេសចរណ៍ពុទ្ធសាសនា_color','#ffc925'), //Tourism
    'សម្លេងយុវជន_color' => env('សម្លេងយុវជន_color','#4caf6c'), //Youth
];